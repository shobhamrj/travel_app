import 'package:flutter/material.dart';
import 'package:exploreskflutteryyyy/horizonal_widget.dart';
import 'package:exploreskflutteryyyy/pages/itineraryDetails/index.dart';



class PackageList extends StatefulWidget {
  @override
  _PackageListState createState() => _PackageListState();
}

class _PackageListState extends State<PackageList> {

  List<ActivityModelPkg> myTopPackages = [
    new ActivityModelPkg(
      title: 'North Exquisite',
      subtitle: 'Sikkim',
      image: 'images/gallery/item11.jpg',
        showFilters: true,
      color: Colors.lightBlueAccent
    ),
    new ActivityModelPkg(
        title: 'East Exquisite',
        subtitle: 'Sikkim',
        image: 'images/gallery/item22.jpg',
        showFilters: true,
        color: Colors.redAccent
    ),
    new ActivityModelPkg(
        title: 'West Exquisite',
        subtitle: 'Sikkim',
        image: 'images/gallery/item23.jpg',
        showFilters: true,
        color: Colors.orange
    ),
    new ActivityModelPkg(
        title: 'South Exquisite',
        subtitle: 'Sikkim',
        image: 'images/gallery/item17.jpg',
        showFilters: true,
        color: Colors.green
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFFAFAFA),
      body: CustomScrollView(
        slivers: <Widget>[
          SliverAppBar(
            leading: new IconButton(
              icon: Icon(Icons.favorite,color: Colors.white,),
            ),
            actions: <Widget>[
              new Container(width: 5.0),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: new Material(
                  shape: new CircleBorder(),
                  child: new Image.asset('images/profile.jpg'),
                ),
              ),
            ],
            pinned: true,
            expandedHeight: 150.0,
            flexibleSpace: FlexibleSpaceBar(
              centerTitle: true,
              title: new Row(
                mainAxisAlignment: MainAxisAlignment.center,
              //crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                new Text('TOP ',style: TextStyle(fontFamily: 'Poiret-One',fontWeight: FontWeight.bold,color: Colors.white,fontSize: 22.0),),
                new Text(' ACTivities'.toUpperCase(),style: TextStyle(fontFamily: 'Poiret-One',color: Colors.white,fontSize: 22.0))
              ],
            ),
              background: Container(
                height: 200.0,
                width: double.infinity,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Color(0xFF52c9ff),Color(0xFF43c5ff),Colors.blue,Colors.blueAccent],
                    begin: FractionalOffset.centerLeft,
                    end: FractionalOffset.centerRight,
                    stops: [0.2,0.5,0.8,1.0]
                    ),
                  ) ,
                ),
            ),
          ),
          SliverGrid(
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 1,
              mainAxisSpacing: 10.0,
              crossAxisSpacing: 20.0,
              childAspectRatio: 1.4
            ),
            delegate: SliverChildBuilderDelegate((BuildContext context , int index){
              return new CardPackage(
                pkgModel: myTopPackages[index],
              );
            },
             childCount: myTopPackages.length,
            ),
          )
        ],
      )
    );
  }
}


class ActivityModelPkg{
  final String image;
  final String title;
  final String subtitle;
  final Color color;
  final bool showFilters;

  ActivityModelPkg({
    this.image,
    this.title,
    this.color,
    this.subtitle,
    this.showFilters
  });

}



class CardPackage extends StatefulWidget {
  final ActivityModelPkg pkgModel;

  CardPackage({
    this.pkgModel
  });

  @override
  _CardPackageState createState() => _CardPackageState();
}

class _CardPackageState extends State<CardPackage> {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 20.0),
      child: Stack(
        fit: StackFit.loose,
        children: <Widget>[
          Card(
            elevation: 5.0,
              child: Container(
                height: 150.0,
                width: double.infinity,
                child: Stack(
                  fit: StackFit.expand,
                  children: <Widget>[
                    Image.asset(
                      widget.pkgModel.image,
                      fit: BoxFit.cover,
                    ),
                    widget.pkgModel.showFilters
                    ? new Container(
                      width: double.infinity,
                      height: double.infinity,
                      decoration: new BoxDecoration(
                        gradient: LinearGradient(
                            colors: [widget.pkgModel.color.withOpacity(0.3),Colors.white.withOpacity(0.2)],
                            begin: FractionalOffset.topRight,
                            end: FractionalOffset.bottomLeft,
                            stops: [0.5,1.0]
                        ),
                      ),
                    ): Container()

                  ],
                ),
              )
          ),

          Container(
            margin:EdgeInsets.only(top:170.0),
            padding: EdgeInsets.only(left:10.0,right: 10.0),
            child: Column(
              children: <Widget>[
                Row(
                  children: <Widget>[
                    Text(
                      widget.pkgModel.title,
                      style: TextStyle(
                          fontFamily: 'Lato',
                          color: Colors.black54,
                          fontSize: 18.0
                      ),
                    ),
                    Expanded(child: Container(),),
                    new IconButton(
                      padding: EdgeInsets.all(0.0),
                      color: widget.pkgModel.showFilters ? widget.pkgModel.color : Colors.lightBlueAccent,
                      icon: Icon(Icons.share),
                      onPressed:() {

                      },
                    )
                  ],
                ),
              ],
            ),
          ),
          Align(
            alignment: Alignment.centerRight,
            child: Transform(
              transform: Matrix4.translationValues(-55.0,25.0,0.0),
              child: Container(
                height: 60.0,
                width: 60.0,
                child: new FloatingActionButton(
                  elevation: 5.0,
                  heroTag: null,
                  backgroundColor:widget.pkgModel.showFilters ? widget.pkgModel.color : Colors.lightBlueAccent,
                  onPressed: (){

                  },
                  child: Icon(Icons.favorite_border),
                ),
              ),
            ),
          ),
          Align(
            alignment: Alignment.centerLeft,
            child:  Transform(
              transform: Matrix4.translationValues(20.0, 25.0, 0.0),
              child: Material(
                elevation: 5.0,
                borderRadius: BorderRadius.circular(30.0),
                color: Colors.transparent,
                child: Ink(
                  child: InkWell(
                    onTap: (){

                    },
                    child: Container(
                        decoration: BoxDecoration(
                            gradient: LinearGradient(
                                colors: [Color(0xFF52c9ff),Color(0xFF43c5ff),Colors.blue,Colors.blueAccent],
                                begin: FractionalOffset.centerLeft,
                                end: FractionalOffset.centerRight,
                                stops: [0.2,0.5,0.8,1.0]
                            ),
                            borderRadius: BorderRadius.circular(30.0),
                        ),
                        padding: EdgeInsets.symmetric(horizontal:15.0,vertical:5.0),

                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: <Widget>[
                            Padding(
                              padding: const EdgeInsets.only(left:8.0),
                              child: new Text('More'.toUpperCase(),
                                style: TextStyle(
                                    color: Colors.white,
                                    fontFamily: 'Lato',
                                    fontSize: 17.0,
                                    fontWeight: FontWeight.bold
                                ),
                              ),
                            ),
                            Icon(Icons.chevron_right,color: Colors.white,),
                          ],
                        )
                    ),
                  ),
                ),
              ),
            ),
          )
        ],
      ),
    );
  }
}


