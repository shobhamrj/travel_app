import 'package:flutter/material.dart';

class HotelForm extends StatefulWidget {
  @override
  _HotelFormState createState() => _HotelFormState();
}

class _HotelFormState extends State<HotelForm> {

  Widget _firstRow(){
    return Row(
      children: <Widget>[
        Expanded(
          flex:2,
          child: ListTile(
            title: Text(
              'Marina Bay sands',
              style: TextStyle(
                  fontWeight: FontWeight.bold
              ),
            ),
            subtitle: Text('xx'),
          ),
        ),
        Expanded(
            child: Container(
                decoration: BoxDecoration(
                    image: DecorationImage(
                        image: AssetImage('images/gallery/item3.jpg'),
                        fit: BoxFit.cover
                    ),
                    borderRadius: BorderRadius.circular(6.0),
                    boxShadow: [
                      BoxShadow(
                          color: Colors.grey,
                          spreadRadius: 2.0,
                          blurRadius: 5.0
                      ),
                    ]
                )
            )
        )
      ],
    );
  }


  Widget _secondRow(){
    return new Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: <Widget>[
        Column(
          children: <Widget>[
            Text(
              'CHECK IN',
              style: TextStyle(
                color: Colors.grey,
                fontWeight: FontWeight.bold,
              ),
            ),
            Material(
              child: InkWell(
                onTap: (){
                  //TODO implement calender
                },
                child: Container(
                  child: Column(
                    children: <Widget>[
                      Text(
                          'SATURDAY'.toUpperCase(),
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                          '29 Apr',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                        ),
                      )
                    ],
                  ),
                ),
              ),
            )

          ],
        ),
        Column(
          children: <Widget>[
            IconButton(icon: Icon(Icons.perm_contact_calendar)),
            Text(
                '4 Nights',
                style: TextStyle(
                color: Colors.grey
              ),
            )
          ],
        ),
        Column(
          children: <Widget>[
            Text(
              'CHECK OUT',
              style: TextStyle(
                color: Colors.grey,
                fontWeight: FontWeight.bold,
              ),
            ),
            Material(
              child: InkWell(
                onTap: (){
                  //TODO implement calender
                },
                child: Container(
                  child: Column(
                    children: <Widget>[
                      Text(
                        'SATURDAY'.toUpperCase(),
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        '29 Apr',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                        ),
                      )
                    ],
                  ),
                ),
              ),
            )

          ],
        ),

      ],
    );
  }


  Widget _thirdRow(){
    return new Row(
      children: <Widget>[
        Column(
          children: <Widget>[
            Text('1 ROOM'),
            Text('Deluxe Room')
          ],
        ),
        Expanded(child: Container(),),
        Column(
          children: <Widget>[
            Text('1 ROOM'),
            Text('Deluxe Room')
          ],
        ),
      ],
    );
  }

  Widget _fourthRow(){
    return Center(
      child: Text(
        'CONTACT DETAILS',
        style: TextStyle(
          fontWeight: FontWeight.bold,
          color: Colors.grey
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0.0,
      ),
      body: Column(
        children: <Widget>[
          _firstRow(),
          Divider(),
          _secondRow()

        ],
      ),
    );
  }
}
