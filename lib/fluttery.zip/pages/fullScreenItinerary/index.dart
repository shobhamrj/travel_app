import 'package:exploreskflutteryyyy/pages/itineraryDetails/index.dart';
import 'package:flutter/material.dart';
import 'package:exploreskflutteryyyy/fluttery/framing.dart';


class FullScreenItinerary extends StatefulWidget {
  @override
  _FullScreenItineraryState createState() => _FullScreenItineraryState();
}

class _FullScreenItineraryState extends State<FullScreenItinerary> with TickerProviderStateMixin{

  AnimationController swipePager;
  Animation<Offset> pageSwipeAnim;



  @override
  void initState(){
    super.initState();
    swipePager = new AnimationController(
        vsync: this,
        duration: Duration(milliseconds: 500)
    )..addListener((){
      print(pageSwipeAnim.value);
    })..addStatusListener((animation){

    });

    pageSwipeAnim = new Tween(begin: Offset(0.0,1.0),end: Offset(0.0,0.0)).animate(new CurvedAnimation(parent: swipePager, curve: Interval(0.0,1.0,curve: Curves.ease)));
  }

  Widget _chipLabel(){
    return new Container(
        margin: EdgeInsets.all(20.0),
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(30.0),
            color: Colors.lightBlueAccent,
            boxShadow: [
              BoxShadow(
                  offset: Offset(0.0,5.0),
                  color: Colors.black.withOpacity(0.3),
                  spreadRadius: 5.0,
                  blurRadius: 10.0
              )
            ]
        ),
        padding: EdgeInsets.symmetric(horizontal:15.0,vertical:10.0),

        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Icon(Icons.card_travel,color: Colors.white,),
            Padding(
              padding: const EdgeInsets.only(left:8.0),
              child: new Text('Travel'.toUpperCase(),
                style: TextStyle(
                    color: Colors.white,
                    fontFamily: 'Lato',
                    fontWeight: FontWeight.bold
                ),
              ),
            ),

          ],
        )
    );
  }

  Widget _hBar(){
    return Padding(
      padding: EdgeInsets.symmetric(vertical:10.0,horizontal: 20.0),
      child: new Container(
        width: 80.0,
        height: 2.0,
        color: Colors.white70,
      ),
    );
  }

  Widget _footText(){
    return Padding(
      padding: const EdgeInsets.symmetric(vertical:15.0,horizontal: 20.0),
      child: new Row(
        children: <Widget>[
          Text(
            'From',
            style: TextStyle(
                color: Colors.white,
                fontFamily: 'Lato'
            ),
          ),
          Text(
            ' Rs 7899 ',
            style: TextStyle(
                color: Colors.lightBlueAccent,
                fontFamily: 'Lato',
                fontWeight: FontWeight.bold
            ),
          ),
          Text(
            ' For 5 Nights',
            style: TextStyle(
                color: Colors.white,
                fontFamily: 'Lato'
            ),
          )
        ],
      ),
    );
  }

  Widget _subTitle(){
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal:10.0,vertical:20.0),
      child: Row(
        children: <Widget>[
          Icon(
            Icons.location_on,
            color: Colors.white,
          ),
          Container(width:5.0),
          Text(
            'North Sikkim , India',
            style: TextStyle(
              color: Colors.white,
              fontFamily: 'Lato',
              fontSize: 16.0,
            ),
          ),
        ],
      ),
    );
  }

  Widget _title(){
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal:15.0),
      child: Text(
        'Gangtok & North Sikkim Tour',
        style: TextStyle(
            color: Colors.white,
            fontFamily: 'Lato',
            fontSize: 27.0,
            fontWeight: FontWeight.bold
        ),
      ),
    );
  }


  @override
  Widget build(BuildContext context) {
    return Material(
      type: MaterialType.transparency,
      child: Scaffold(
          body: Stack(
            children: <Widget>[
              Stack(
                children: <Widget>[
                  new Container(
                    width: double.infinity,
                    height: double.infinity,
                    child: new Image.asset('images/gallery/item8.jpg',fit: BoxFit.cover,),
                  ),
                  new Container(
                    width: double.infinity,
                    height: double.infinity,
                    color: Colors.black.withOpacity(0.3),
                    child: Opacity(opacity: 0.7,child: new Image.asset('images/shadow.png',fit: BoxFit.cover,)),
                  ),
                  new Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: <Widget>[
                        Container(
                          padding:EdgeInsets.only(top:130.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              _chipLabel(),
                              _title(),
                              _subTitle(),
                              _hBar(),
                              _footText(),
                              GalleryBuilder(
                                imagesList: [
                                  'images/gallery/item2.jpg',
                                  'images/gallery/item4.jpg',
                                  'images/gallery/item3.jpg',
                                  'images/gallery/item6.jpg',
                                  'images/gallery/item7.jpg',
                                  'images/gallery/item2.jpg',
                                  'images/gallery/item4.jpg',
                                  'images/gallery/item3.jpg',
                                  'images/gallery/item6.jpg',
                                  'images/gallery/item7.jpg',
                                ],
                              ),

                            ],
                          ),
                        )
                      ]
                  ),
                  Align(
                    alignment: FractionalOffset.bottomCenter,
                    child: Container(
                      height: 45.0,
                      //padding: const EdgeInsets.symmetric(horizontal:8.0,vertical:20.0),
                      child: GestureDetector(
                        behavior: HitTestBehavior.opaque,
                        onVerticalDragStart: (DragStartDetails details){
                          swipePager.forward(from:0.0);
                        },
                        child: new Row(
                          mainAxisSize: MainAxisSize.max,
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: <Widget>[
                            new Icon(
                              Icons.info_outline,
                              color: Colors.white,
                            ),
                            new Text(
                              'Swipe up for more details',
                              style: TextStyle(
                                  color: Colors.white,
                                  fontFamily: 'Lato'
                              ),
                            ),
                            new Icon(
                              Icons.keyboard_arrow_up,
                              color: Colors.lightBlueAccent,
                            )
                          ],
                        ),
                      ),
                    ),
                  )
                ],
              ),
              AnimatedBuilder(
                animation: swipePager,
                builder: (BuildContext context , Widget child){
                  return new FractionalTranslation(
                    translation: Offset(pageSwipeAnim.value.dx , pageSwipeAnim.value.dy),
                    child: new PackageDetails(
                        optionalAnimController:swipePager
                    ),
                  );
                },
              )
            ],
          )
      ),
    );
  }
}




class GalleryBuilder extends StatefulWidget {
  final List imagesList;
  GalleryBuilder({
    this.imagesList
  });
  @override
  _GalleryBuilderState createState() => _GalleryBuilderState();
}

class _GalleryBuilderState extends State<GalleryBuilder> {

  Widget _singleGalleryItem(String itemPath){
    return Padding(
      padding: EdgeInsets.all(8.0),
      child: Stack(
        children: <Widget>[
          new Container(
            width: 50.0,
            height: 50.0,
            decoration: BoxDecoration(
                image: DecorationImage(image: AssetImage(itemPath),fit: BoxFit.cover),
                borderRadius: BorderRadius.circular(5.0)
            ),
          ),
          Container(
            width: 50.0,
            height: 50.0,
            decoration: BoxDecoration(
                gradient: LinearGradient(
                    colors: [Colors.blueAccent.withOpacity(0.4),Colors.white.withOpacity(0.2)],
                    begin: FractionalOffset.bottomLeft,
                    end: FractionalOffset.topRight,
                    stops: [0.2,1.0]
                ),
                borderRadius: BorderRadius.circular(5.0)
            ),
          )
        ],
      ),
    );
  }

  _buildChildren(){
    return widget.imagesList.map((item){
      return _singleGalleryItem(item);
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.all(10.0),
      child: Container(
          height: 80.0,
          child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: widget.imagesList.length,
              itemBuilder: (BuildContext context,int index){
                return _singleGalleryItem(widget.imagesList[index]);
              })
      ),
    );
  }
}
