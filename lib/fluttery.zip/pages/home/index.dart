import 'package:exploreskflutteryyyy/horizonal_widget.dart';
import 'package:exploreskflutteryyyy/pages/itineraryDetails/index.dart';
import 'package:flutter/material.dart';


List<Map> myTopDestinations = [
  {
    'bgImg':'images/gallery/item4.jpg',
    'title':'Gangtok',
    'subtitle':'SIKKIM',
  },
  {
    'bgImg':'images/gallery/item22.jpg',
    'title':'Gangtok',
    'subtitle':'SIKKIM',
  },
  {
    'bgImg':'images/gallery/item3.jpg',
    'title':'Gangtok',
    'subtitle':'SIKKIM',
  }
];


class HomeApp extends StatefulWidget {
  @override
  _HomeAppState createState() => _HomeAppState();
}

class _HomeAppState extends State<HomeApp> with TickerProviderStateMixin{
  @override
  Widget build(BuildContext context) {
    return Material(
      child: Scaffold(
        appBar: AppBar(
          actions: <Widget>[
            new Container(width: 5.0),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: new Material(
                shape: new CircleBorder(),
                child: new Image.asset('images/profile.jpg'),
              ),
            ),
          ],
          backgroundColor: Colors.white,
          centerTitle: true,
          leading: new IconButton(icon: Icon(Icons.menu,color: Colors.black26,), onPressed: (){}),
          title: Text('ACTIVITIES & TOUR',style: TextStyle(color:Colors.black45,fontWeight: FontWeight.bold),),
          elevation: 0.0,
        ),
        body: ListView(
          children: <Widget>[
            new ClipPath(
              clipper: ArcClipper(),
              child: new Container(
                decoration: BoxDecoration(
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black,
                      blurRadius: 6.0,
                      spreadRadius: 2.0,
                      offset: Offset(0.0,20.0)
                    )
                  ],
                  color:Colors.lightBlueAccent
                ),
                width: double.infinity,
                height: 200.0,
              ),
            ),
            Column(
              children: <Widget>[
                PackageStar(
                  duration: '5N.6D',
                  pkgTitle: 'Gangtok 5 Nights - Super Saver',
                  subTitle: '5N Gangtok',
                  footerInclusion: 'Includes Hotels , Luxury Car , Sightseeing , Transfers on Arrival',
                  tag: 'Friends / Family',
                  crossedRate: 'Rs  14,215',
                  savedString: 'Save Rs 3,201 (27 %)',
                  image: 'images/gallery/item11.jpg',
                  rate: 'Rs  10,014',
                  stars: 4.5,
                ),
                PackageStar(
                  duration: '5N.6D',
                  pkgTitle: 'Gangtok 5 Nights - Super Saver',
                  subTitle: '5N Gangtok',
                  footerInclusion: 'Includes Hotels , Luxury Car , Sightseeing , Transfers on Arrival',
                  tag: 'Friends / Family',
                  crossedRate: 'Rs  14,215',
                  savedString: 'Save Rs 3,201 (27 %)',
                  image: 'images/gallery/item27.jpg',
                  rate: 'Rs  10,014',
                  stars: 4.5,
                ),
                new GradientHorizontalListWidgetWithImages(
                  gradientColors: [Colors.deepOrangeAccent,Colors.redAccent,Colors.pink],
                  title: 'TOP',
                  subTitle: 'Packages',
                  items: myTopDestinations,
                  showSaveIcon: true,
                  cardTextAlignment: CrossAxisAlignment.start,
                  bannerTextAlignment: CrossAxisAlignment.start,
                  cardTapHandler: (x){
                    Navigator.push(context, new MaterialPageRoute(builder: (BuildContext context) => new PackageDetails()));
                  },
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }


}



class ArcClipper extends CustomClipper<Path>{
  @override
  Path getClip(Size size) {
    var path = new Path();
    path.lineTo(0.0, size.height - 30);

    var firstControlPoint = new Offset(size.width / 4, size.height);
    var firstPoint = new Offset(size.width / 2, size.height);
    path.quadraticBezierTo(firstControlPoint.dx, firstControlPoint.dy,
        firstPoint.dx, firstPoint.dy);

    var secondControlPoint =
    new Offset(size.width - (size.width / 4), size.height);
    var secondPoint = new Offset(size.width, size.height - 30);
    path.quadraticBezierTo(secondControlPoint.dx, secondControlPoint.dy,
        secondPoint.dx, secondPoint.dy);

    path.lineTo(size.width, 0.0);
    path.close();

    return path;
  }

  @override
  bool shouldReclip(CustomClipper<Path> oldClipper) {
    return false;
  }

}


class PackageStar extends StatefulWidget {
  final String duration;
  final String pkgTitle;
  final String subTitle;
  final String footerInclusion;
  final String tag;
  final String crossedRate;
  final String savedString;
  final String image;
  final String rate;
  final double stars;
  PackageStar({
    this.image,
    this.duration,
    this.crossedRate,
    this.footerInclusion,
    this.pkgTitle,
    this.savedString,
    this.subTitle,
    this.tag,
    this.rate,
    this.stars
  });

  @override
  _PackageStarState createState() => _PackageStarState();
}

class _PackageStarState extends State<PackageStar> {


  Widget floatingBtnIcon(Icon icon , int index){
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 5.0),
      child: new FloatingActionButton(
          heroTag: null,
          elevation: 0.0,
          backgroundColor: Colors.white,
          onPressed: (){

          },
          child: icon
      ),
    );
  }

  Widget pkgDuration(){
    return new Container(
      alignment: Alignment.center,
      padding:EdgeInsets.symmetric(vertical:8.0,horizontal: 15.0),
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(30.0),
          gradient: new LinearGradient(
              colors: [Colors.blue,Colors.lightBlueAccent,Colors.lightBlue],
              begin: new FractionalOffset(1.0, 0.0),
              end: new FractionalOffset(0.0, 1.0),
              stops: [0.2,0.6,1.0]
          )
      ),
      child: new Text(
        widget.duration,
        style: TextStyle(
            color: Colors.white,
            fontSize: 12.0
        ),
      ),
    );
  }

  Widget _buildStars(double index){
    int inc = index.floor();
    List<Widget> builtStars = [];

    for(int i=0;i<inc;i++){
      builtStars.add(
          Padding(
            padding: const EdgeInsets.all(1.0),
            child: new Icon(
              Icons.star,
              color: new Color(0xFFffd700),
              size: 16.0,
            ),
          )
      );
    }
    for(int i=inc;i<5;i++){
      builtStars.add(
          Padding(
            padding: const EdgeInsets.all(1.0),
            child: new Icon(
              Icons.star,
              color: Color(0xFFEFEFEF),
              size: 16.0,
            ),
          )
      );
    }
    return new Row(
        children: builtStars
    );
  }

  Widget _cardBody(){
    return Padding(
      padding: const EdgeInsets.only(top:20.0,left:10.0,right: 10.0,bottom: 10.0),
      child: new Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Container(
            child: Text(
              widget.pkgTitle,
              style: TextStyle(
                  fontSize: 13.0,
                  fontFamily: 'Lato'
              ),
            ),
          ),
          new Row(
            children: <Widget>[
              Column(
                children: <Widget>[
                  Text(
                    widget.subTitle,
                    style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 17.0,
                        fontFamily: 'Lato'
                    ),
                  ),
                  _buildStars(widget.stars)
                ],
              ),
              new Expanded(child: Container(),),
              new Column(
                children: <Widget>[
                  Text(
                    widget.crossedRate,
                    style: TextStyle(
                        fontSize: 10.0,
                        color:Colors.grey,
                        fontFamily: 'Lato',
                        decorationStyle: TextDecorationStyle.dotted
                    ),
                  ),
                  Text(
                    widget.rate,
                    style: TextStyle(
                        fontSize: 20.0,
                        color:Colors.black87,
                        fontFamily: 'Lato',
                        decorationStyle: TextDecorationStyle.dotted
                    ),
                  ),
                  Text(
                    'Price/Person',

                    style: TextStyle(
                        fontSize: 10.0,
                        color:Colors.black87,
                        fontFamily: 'Lato',
                        fontStyle: FontStyle.italic,
                        decorationStyle: TextDecorationStyle.dotted
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top:5.0),
                    child: Text(
                      widget.savedString,
                      style: TextStyle(
                          fontSize: 12.0,
                          color:Colors.red,
                          fontFamily: 'Lato',
                          decorationStyle: TextDecorationStyle.dotted
                      ),
                    ),
                  ),
                ],
              )
            ],
          ),
          Padding(
            padding: const EdgeInsets.only(top:10.0),
            child: new Row(
              children: <Widget>[
                new Expanded(
                  flex: 2,
                  child: Text(
                    widget.footerInclusion,
                    style: TextStyle(
                        fontSize: 10.0,
                        color:Colors.black87,
                        fontFamily: 'Lato',
                        fontStyle: FontStyle.italic,
                        decorationStyle: TextDecorationStyle.dotted
                    ),
                  ),
                ),
                new Expanded(
                  child: new Container(
                    padding: EdgeInsets.all(4.0),
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                        color: Colors.blueAccent,
                        borderRadius: BorderRadius.circular(30.0)
                    ),
                    child: new Text(
                      widget.tag,
                      style: TextStyle(
                        fontSize: 12.0,
                        color:Colors.white,
                        fontFamily: 'Lato',
                        fontStyle: FontStyle.normal,
                      ),
                    ),
                  ),
                )
              ],
            ),
          )
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: <Widget>[
        Container(
            width:double.infinity,
            height: 150.0,
            child: new Image.asset(widget.image,fit: BoxFit.cover,)
        ),
        new Container(
          padding: EdgeInsets.only(top:100.0,left:10.0,right: 10.0,bottom: 10.0),
          child: Stack(
            children: <Widget>[
              Container(
                width: MediaQuery.of(context).size.width,
                height: 170.0,
                child: GestureDetector(
                  onTap: (){
                    Navigator.pushNamed(context, '/packageFullScreenDetail');
                  },
                  child: new Card(
                      child: _cardBody()
                  ),
                ),
              ),
              Transform(
                transform: Matrix4.translationValues(0.0, -24.0, 0.0),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal:15.0),
                  child: Row(
                    children: <Widget>[
                      pkgDuration(),
                      Expanded(child: Container(),),
                      floatingBtnIcon(
                          Icon(
                            Icons.share,
                            color: Colors.black45,
                          ),1
                      ),
                      floatingBtnIcon(
                          Icon(
                            Icons.favorite_border,
                            color: Colors.black45,
                          ),2
                      ),

                    ],
                  ),
                ),
              )
            ],
          ),
        )
      ],
    );
  }
}
